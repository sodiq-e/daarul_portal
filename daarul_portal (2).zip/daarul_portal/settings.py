from pathlib import Path
import os
import dj_database_url
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'django-insecure-9x4k8f2z3y!temporary-safe-key-change-me'
DEBUG = os.environ.get('DEBUG', 'False') == 'True'
ALLOWED_HOSTS = [
    "daarulbayaan.pythonanywhere.com",
    "127.0.0.1",
    "localhost",
    "onrender.com",
    "daarul-portal.onrender.com",
]
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
     'cloudinary',
     'cloudinary_storage',

    'rest_framework',
    'admin_interface',
    'colorfield',
    'ckeditor',

    'settingsapp',
    'accounts',
    'students',
    'exams',
    'results',
    'psychomotor',
    'attendance',
    'staff_attendance.apps.StaffAttendanceConfig',
    'school_classes.apps.SchoolClassesConfig',
    'payroll',
    'announcements',
    'communication',
    'pages',
    'cbt.apps.CbtConfig',
]


MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
]
ROOT_URLCONF = 'daarul_portal.urls'
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'settingsapp.context_processors.school_settings',
                'settingsapp.context_processors.announcements_context',
                'settingsapp.context_processors.print_verification_context',
                'pages.context_processors.navigation_pages',
                'communication.context_processors.portal_messages_context',
            ],
        },
    },
]
WSGI_APPLICATION = 'daarul_portal.wsgi.application'
# DATABASES = {
#     'default': dj_database_url.parse(
#        # os.environ.get("DATABASE_URL")
#        "postgresql://neondb_owner:npg_l8rZEM6wNiho@ep-raspy-shadow-ahxv2ikr.c-3.us-east-1.aws.neon.tech/neondb?sslmode=require"
#     )
# }
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = []
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Africa/Lagos'
USE_I18N = True
USE_TZ = True
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
SCHOOL_NAME = 'Daarul Bayaan Islamic School'
SCHOOL_MOTTO = 'Knowledge for the fear of God'
SCHOOL_LOGO = '/static/img/logo.png'



LOGIN_REDIRECT_URL = '/'
LOGIN_URL = 'login'

import os
#import cloudinary

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
STATIC_URL

# cloudinary.config(
#     cloud_name="da7ow7upe",
#     api_key="1834834285833157",
#     api_secret="Y6-oaGrH9i2XV8T-99M3AILoek8",
#     secure=True
# )


# CLOUDINARY_STORAGE = {
#     'CLOUD_NAME': 'da7ow7upe',
#     'API_KEY': '183483428583157',
#     'API_SECRET': 'Y6-oaGrH9i2XV8T-99M3AILoek8',
# }

#DEFAULT_FILE_STORAGE = 'cloudinary_storage.storage.MediaCloudinaryStorage'
# CKEditor Configuration for Exam Papers
CKEDITOR_CONFIGS = {
    'default': {
        'skin': 'moono',
        'toolbar_ExamPaper': [
            {
                'name': 'basicstyles',
                'items': ['Bold', 'Italic', 'Underline', 'Strike', '-', 'RemoveFormat']
            },
            {
                'name': 'paragraph',
                'items': ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock']
            },
            {
                'name': 'links',
                'items': ['Link', 'Unlink']
            },
            {
                'name': 'insert',
                'items': ['Image', 'Table', '-', 'SpecialChar']
            },
            {
                'name': 'styles',
                'items': ['Styles', 'Format', 'FontSize']
            },
            {
                'name': 'colors',
                'items': ['TextColor', 'BGColor']
            },
            {
                'name': 'tools',
                'items': ['Maximize', 'ShowBlocks']
            },
        ],
        'toolbar_Question': [
            {
                'name': 'document',
                'items': ['Source', '-', 'Save', 'NewPage', 'DocProps', 'Preview', 'Print', '-', 'Templates']
            },
            {
                'name': 'editing',
                'items': ['Find', 'Replace', '-', 'SelectAll', '-', 'SpellChecker', 'Scayt']
            },
            {
                'name': 'forms',
                'items': ['Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField']
            },
            '/',
            {
                'name': 'basicstyles',
                'items': ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat']
            },
            {
                'name': 'paragraph',
                'items': ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl']
            },
            {
                'name': 'links',
                'items': ['Link', 'Unlink', 'Anchor']
            },
            {
                'name': 'insert',
                'items': ['Image', 'Flash', 'Table', '-', 'SpecialChar', 'Iframe']
            },
            '/',
            {
                'name': 'styles',
                'items': ['Styles', 'Format', 'Font', 'FontSize']
            },
            {
                'name': 'colors',
                'items': ['TextColor', 'BGColor']
            },
            {
                'name': 'tools',
                'items': ['Maximize', 'ShowBlocks']
            },
            {
                'name': 'about',
                'items': ['About']
            }
        ],
        'toolbar': 'Question',
        'height': 400,
        'width': '100%',
        'tabSpaces': 4,
        'allowedContent': True,
        'contentsCss': ['/static/css/ckeditor-content.css'],
        'removePlugins': 'elementspath',
        'filebrowserUploadUrl': '/ckeditor/upload/',
        'filebrowserBrowseUrl': '/ckeditor/browse/',
        'extraPlugins': ['mathjax'],
        'mathJaxLib': 'https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-AMS_HTML',
    }
}

# Session configuration
SESSION_ENGINE = 'django.contrib.sessions.backends.db'

# Email Configuration for Password Reset
# For development, use console backend (emails printed to console)
EMAIL_BACKEND = os.environ.get(
    'EMAIL_BACKEND',
    'django.core.mail.backends.console.EmailBackend'
)

# For production, configure with actual email service:
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'smtp.gmail.com')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', 587))
EMAIL_USE_TLS = os.environ.get('EMAIL_USE_TLS', 'True') == 'True'
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')

DEFAULT_FROM_EMAIL = 'noreply@daaraulportal.com'

# Security settings for production
if not DEBUG:
    SECURE_SSL_REDIRECT = False
    SESSION_COOKIE_SECURE = False
    CSRF_COOKIE_SECURE = False
    SECURE_BROWSER_XSS_FILTER = True
    SECURE_HSTS_SECONDS = 0 #int(os.environ.get('SECURE_HSTS_SECONDS', 31536000))  # 1 year
    SECURE_HSTS_INCLUDE_SUBDOMAINS = False
    SECURE_HSTS_PRELOAD = False
    SECURE_CONTENT_SECURITY_POLICY = {
        "default-src": ("'self'",),
    }

AI_GENERATION_ENABLED = os.environ.get('AI_GENERATION_ENABLED', 'True').strip().lower() not in ('0', 'false', 'no')

# Exam resource upload settings
EXAM_UPLOAD_MAX_SIZE = int(os.environ.get('EXAM_UPLOAD_MAX_SIZE', 5 * 1024 * 1024))  # bytes
EXAM_UPLOAD_WHITELIST = os.environ.get('EXAM_UPLOAD_WHITELIST', 'png,jpg,jpeg,gif').split(',')
EXAM_UPLOAD_CLEANUP_DAYS = int(os.environ.get('EXAM_UPLOAD_CLEANUP_DAYS', 90))
# If set to True and clamd is available, uploaded files will be scanned. Requires python-clamd or similar.
EXAM_UPLOAD_USE_CLAMD = os.environ.get('EXAM_UPLOAD_USE_CLAMD', 'False').strip().lower() in ('1','true','yes')

